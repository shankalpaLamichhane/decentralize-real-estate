'use strict';
console.log('Loading function');

exports.handler = (event,context,callback) => {
    console.log('------------- Lambda is triggered ------------');
    callback(null,Math.floor(Math.random()*10)+0);
}